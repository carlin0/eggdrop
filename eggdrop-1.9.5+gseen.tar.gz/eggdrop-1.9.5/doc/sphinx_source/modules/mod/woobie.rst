Last revised: December 31, 2001

.. _woobie:

Woobie Module
-------------

This is for demonstrative purposes only. If you are looking for starting
point in writing modules, woobie is the right thing.

This module requires: none

Put this line into your Eggdrop configuration file to load the woobie
module::

  loadmodule woobie

Copyright (C) 2000 - 2023 Eggheads Development Team
