Last revised: January 1, 2002

.. _assoc:

============
Assoc Module
============

This module provides assoc support, i.e. naming channels on the botnet.

This module requires: none

Put this line into your Eggdrop configuration file to load the assoc
module::

    loadmodule assoc

Copyright (C) 2000 - 2023 Eggheads Development Team
