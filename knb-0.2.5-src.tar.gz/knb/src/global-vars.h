
/* times */
extern time_t now;

/* me */
extern struct knb_user me;

/* userlist */
extern struct knb_userlist *first_user, *user, *user2;
/* queue */
extern struct knb_queue queue[MAX_QUEUE];
extern int queues;
