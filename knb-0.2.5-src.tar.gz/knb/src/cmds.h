void got_cmd(char *who, char *to, char *cmd, char *args);
