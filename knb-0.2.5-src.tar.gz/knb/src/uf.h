#define UF_USERMASK	"01"
#define UF_CHANNEL	"02"
#define UF_TEMPNICK	"03"

bool set_variable2(char *var, char *args, char *error);
bool load_uf(char *file);
bool save_uf(char *file);

