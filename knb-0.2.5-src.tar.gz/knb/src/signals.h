void sig_term(int s);
void sig_int(int s);
void sig_hup(int s);
void sig_segv(int s);
void safe_exit(int s);
void sig_updated(int s);
void sig_updated2(int s);
void signal_handling(void);

