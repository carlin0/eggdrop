Known Problems
Last revised: April 16, 2003

==============
Known Problems
==============

  Things that are broken, but aren't getting fixed anytime soon:

    * Non-working alarm(10) in Linux (calls to gethostbyaddr/name() have
      blocked for long periods when bind/named doesn't resolve quickly, and
      the alarm does not interrupt it).

      Note: This should now work if you use the dns module.

    * High-bit characters are being filtered from channel names. This is a
      fault of the Tcl interpreter, and not Eggdrop. The Tcl interpreter
      filters the characters when it reads a file for interpreting. Update
      your Tcl to version 8.1 or higher.

    * Version 8.1 of Tcl doesn't support unicode characters.
      If those characters are handled in a script as text, you run into errors.
      Eggdrop can't handle these errors at the moment.

  Copyright (C) 2003 - 2022 Eggheads Development Team
