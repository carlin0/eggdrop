:orphan:

.. Eggdrop documentation master file, created by
   sphinx-quickstart on Tue Jun 28 18:48:35 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. toctree::
   :maxdepth: 2

   firstinstall

Placeholder!
============
This doesn't belong here- copy firstinstall.html over index.html
