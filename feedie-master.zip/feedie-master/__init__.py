#!/usr/bin/env python
# -*- coding: utf-8 -*-

__title__ = 'feedie'
__version__ = '1.0'
__author__ = 'meigrafd <meiraspi@gmail.com>'
__repo__ = 'https://github.com/meigrafd/feedie'
__license__ = 'Creative Commons License (BY-NC-SA)'